document.addEventListener('DOMContentLoaded', () => {
    const chatHistory = document.getElementById('chat-history');
    const userInput = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');
    const comicImage = document.getElementById('comic-image');
    const imageLoader = document.getElementById('image-loader');
    const placeholderText = document.querySelector('.placeholder-text');

    // New Creator Panel Elements
    const npcNameInput = document.getElementById('npc-name');
    const npcPersonaInput = document.getElementById('npc-persona');
    const generateDialogueBtn = document.getElementById('generate-dialogue-btn');
    const dialogueOutput = document.getElementById('generated-dialogue-output');
    
    const chatTitle = document.getElementById('chat-title');
    const initialMessageBubble = document.getElementById('npc-initial-bubble');
    const npcAvatarLetter = document.getElementById('npc-avatar-letter');

    let history = [];

    // Helper to get current dynamic system prompt
    function getSystemPrompt() {
        return `You are playing the role of: ${npcNameInput.value}. Your persona and scenario: ${npcPersonaInput.value}. Keep your responses short, under 3 sentences, engaging, and stay strictly in character.`;
    }

    // Update the UI if user changes the NPC Name
    npcNameInput.addEventListener('input', () => {
        chatTitle.textContent = npcNameInput.value || "Unknown NPC";
        npcAvatarLetter.textContent = (npcNameInput.value || "U").charAt(0).toUpperCase();
    });

    // Generate Sample Dialogue Logic
    generateDialogueBtn.addEventListener('click', async () => {
        const name = npcNameInput.value.trim() || "NPC";
        const persona = npcPersonaInput.value.trim();
        
        generateDialogueBtn.disabled = true;
        generateDialogueBtn.textContent = "Generating...";
        dialogueOutput.style.display = "block";
        dialogueOutput.textContent = "Connecting to AI Core to generate dialogue tree...";

        const prompt = `Generate 3 short, distinct sample dialogue lines for a video game NPC named ${name}. Persona: ${persona}. Format as a simple list. Do not include extra text.`;

        try {
            const res = await fetch('https://text.pollinations.ai/openai/chat/completions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    messages: [{ role: 'user', content: prompt }],
                    model: 'openai'
                })
            });
            if (res.ok) {
                const data = await res.json();
                const text = data.choices[0].message.content;
                dialogueOutput.textContent = text;
                
                // Update the initial message to the first generated line (rough extraction)
                const firstLine = text.split('\n').find(line => line.trim().length > 5) || text;
                initialMessageBubble.textContent = firstLine.replace(/^[-*1-3.]\s*/, '').replace(/"/g, '');
                
                // Clear chat history if user starts fresh
                const initialMsgHTML = chatHistory.firstElementChild.outerHTML;
                chatHistory.innerHTML = initialMsgHTML;
                history = [];
                
            } else {
                dialogueOutput.textContent = "Error: Could not generate dialogue.";
            }
        } catch (e) {
            dialogueOutput.textContent = "Error: Network issue generating dialogue.";
        } finally {
            generateDialogueBtn.disabled = false;
            generateDialogueBtn.textContent = "Generate Sample Dialogue";
        }
    });

    function addMessage(role, text) {
        const msgDiv = document.createElement('div');
        msgDiv.className = `message ${role === 'user' ? 'user-message' : 'npc-message'}`;
        
        const avatar = document.createElement('div');
        avatar.className = 'avatar';
        avatar.textContent = role === 'user' ? 'U' : 'M';
        
        const bubble = document.createElement('div');
        bubble.className = 'bubble';
        bubble.textContent = text;
        
        msgDiv.appendChild(avatar);
        msgDiv.appendChild(bubble);
        chatHistory.appendChild(msgDiv);
        
        // Scroll to bottom
        chatHistory.scrollTop = chatHistory.scrollHeight;
        
        // Add to history array
        history.push({ role, content: text });
    }

    async function setTypingIndicator(show) {
        if (show) {
            const msgDiv = document.createElement('div');
            msgDiv.className = 'message npc-message typing-indicator';
            msgDiv.id = 'typing';
            
            const avatar = document.createElement('div');
            avatar.className = 'avatar';
            avatar.textContent = 'M';
            
            const bubble = document.createElement('div');
            bubble.className = 'bubble';
            bubble.innerHTML = '...'; // Simple typing dots
            
            msgDiv.appendChild(avatar);
            msgDiv.appendChild(bubble);
            chatHistory.appendChild(msgDiv);
            chatHistory.scrollTop = chatHistory.scrollHeight;
        } else {
            const typing = document.getElementById('typing');
            if (typing) typing.remove();
        }
    }

    async function getNPCResponse(userMessage) {
        setTypingIndicator(true);
        sendBtn.disabled = true;
        
        try {
            let reply = "";
            // Try backend first
            try {
                const res = await fetch('http://localhost:3000/api/chat', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        message: userMessage, 
                        history,
                        systemPrompt: getSystemPrompt(),
                        npcName: npcNameInput.value 
                    })
                });
                if (res.ok) {
                    const data = await res.json();
                    reply = data.reply;
                } else {
                    throw new Error("Backend failed");
                }
            } catch (e) {
                // Fallback to direct API call if backend isn't running
                console.log("Backend not reachable, falling back to direct API call...");
                
                let messages = [
                    { role: 'system', content: getSystemPrompt() }
                ];
                history.forEach(entry => {
                    messages.push({
                        role: entry.role === 'user' ? 'user' : 'assistant',
                        content: entry.content
                    });
                });
                messages.push({ role: 'user', content: userMessage });
                
                const res = await fetch('https://text.pollinations.ai/openai/chat/completions', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ messages, model: 'openai' })
                });
                if (res.ok) {
                    const data = await res.json();
                    reply = data.choices[0].message.content;
                } else {
                    reply = "*glitches* My systems are down, traveler. Come back later.";
                }
            }

            setTypingIndicator(false);
            addMessage('npc', reply);
            
            // Trigger image generation based on the NPC's response
            generateComicPanel(reply);

        } catch (error) {
            console.error("Error:", error);
            setTypingIndicator(false);
            addMessage('npc', "*static noise* Comm-link broken.");
        } finally {
            sendBtn.disabled = false;
            userInput.focus();
        }
    }

    async function generateComicPanel(npcText) {
        comicImage.style.display = 'none';
        placeholderText.style.display = 'none';
        imageLoader.style.display = 'block';

        try {
            let imageUrl = "";
            const sceneDescription = npcText.substring(0, 100); // Take first 100 chars as context

            // Try backend first
            try {
                const characterContext = `${npcNameInput.value}, ${npcPersonaInput.value}`;
                const res = await fetch('http://localhost:3000/api/image', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ sceneDescription, characterContext })
                });
                if (res.ok) {
                    const data = await res.json();
                    imageUrl = data.imageUrl;
                } else {
                    throw new Error("Backend failed");
                }
            } catch (e) {
                // Fallback to direct API call
                console.log("Backend not reachable for image, falling back to direct API call...");
                const characterContext = `${npcNameInput.value}, ${npcPersonaInput.value}`;
                const imagePrompt = `${characterContext}, talking, comic book style panel, detailed line art, cinematic lighting, ${sceneDescription}`;
                const encodedPrompt = encodeURIComponent(imagePrompt);
                const randomSeed = Math.floor(Math.random() * 1000000);
                imageUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=800&height=400&nologo=true&seed=${randomSeed}`;
            }

            // Pre-load image to avoid flickering
            const img = new Image();
            img.onload = () => {
                comicImage.src = imageUrl;
                imageLoader.style.display = 'none';
                comicImage.style.display = 'block';
                comicImage.style.opacity = 1;
            };
            img.src = imageUrl;

        } catch (error) {
            console.error("Image generation error:", error);
            imageLoader.style.display = 'none';
            placeholderText.style.display = 'block';
            placeholderText.textContent = "Visual feed corrupted.";
        }
    }

    function handleSend() {
        const text = userInput.value.trim();
        if (text) {
            addMessage('user', text);
            userInput.value = '';
            getNPCResponse(text);
        }
    }

    sendBtn.addEventListener('click', handleSend);
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') handleSend();
    });
});
